package assignments;

public class Fibo 
{
public static void main(String[] args) 
{
	int n = 8;
	int StartingNo = 0;
	int NextNo = 1;
    
    System.out.println("Fibonacci Series Upto " + n + ": ");
    
    while (StartingNo <= n) 
    {
      System.out.print(StartingNo + ", ");

      int ThirdTerm = StartingNo + NextNo;
      StartingNo = NextNo;
      NextNo = ThirdTerm;
    }
}
}
