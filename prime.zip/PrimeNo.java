package assignments;

public class PrimeNo
{
public static void main(String[] args) 
{
	int i = 2;
	int num = 29;
	boolean flag = true;
	for(int i1 = 2;i1 <= num / 2; ++i1);
	{
		if(num % i == 0) 
		{
			
		}
	}
	if (flag) 
	{
		System.out.println(num   +"is a prime no");
	}
	else 
	{
		System.out.println(num    +"is not a prime no");
	}
}
}
